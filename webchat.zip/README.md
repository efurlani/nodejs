# Webchat
Esse é um webchat simples, foi criado utilizando a [documentação do SocketIO](https://socket.io/get-started/chat)

# Como usar
1. Faça o download do repositório
    - git clone git@github.com:gabrielpetry/webchat.git
2. Instale as depêndencias
    - npm install
3. Inicia o servidor
    - npm start

Esse é um wrapper da [documentação do SocketIO](https://socket.io/get-started/chat) mostrando como criar um webchat.

E pode ser utilizado para extender as funcionabilidades e aplicabilidade para qualquer coisa :) 

